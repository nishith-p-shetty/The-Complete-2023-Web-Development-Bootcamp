import React from "react";

function App() {
  const [name, setName] = React.useState({ fName: "", lName: "" });

  function onChg(event) {
    setName({
      fName: event.target.form.fName.value,
      lName: event.target.form.lName.value
    });
  }

  return (
    <div className="container">
      <h1>
        Hello {name.fName} {name.lName}
      </h1>
      <form onChange={onChg}>
        <input name="fName" value={name.fName} placeholder="First Name" />
        <input name="lName" value={name.lName} placeholder="Last Name" />
        <button>Submit</button>
      </form>
    </div>
  );
}

export default App;
