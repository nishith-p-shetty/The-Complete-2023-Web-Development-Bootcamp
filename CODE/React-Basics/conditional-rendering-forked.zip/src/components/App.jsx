import React from "react";
import Login from "./Login";

var isLoggedIn = false;

function App() {
  return <div className="container">{isLoggedIn ? "Hello" : <Login />}</div>;
}

export default App;
