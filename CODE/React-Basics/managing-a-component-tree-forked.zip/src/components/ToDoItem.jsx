import React, { useState } from "react";

function ToDoItem(props) {
  const [isClicked, setClick] = useState(false);

  function handleClick() {
    setClick((prevValue) => !prevValue);
  }
  return (
    <li
      onClick={() => props.onChecked(props.id)}
      style={{ textDecoration: isClicked ? "line-through" : "none" }}
    >
      {props.text}
    </li>
  );
}

export default ToDoItem;
