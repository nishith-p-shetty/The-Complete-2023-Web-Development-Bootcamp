import { useState } from "react";
import "../../public/styles.css";

export default function App() {
  const [countVal, setCountVal] = useState(0);

  function increment() {
    setCountVal(countVal + 1);
  }

  function decrement() {
    setCountVal(countVal - 1);
  }

  return (
    <div className="App">
      <div className="container">
        <h1>{countVal}</h1>
        <button onClick={decrement}>-</button>
        <button onClick={increment}>+</button>
      </div>
    </div>
  );
}
