import React from "react";
import ReactDOM from "react-dom";

const fname = "Abc";
const mname = "Def";
const lname = "Ghi";
const randno = 4;

ReactDOM.render(
  <div>
    <h1>Hello {fname}!</h1>
    <h1>Hello {`${fname} ${mname} ${lname}`}!</h1>
    <p>
      Your lucky number is {randno}, {Math.floor(Math.random() * 10)}
    </p>
  </div>,
  document.getElementById("root")
);
