import React from "react";
import Dd from "./Dd";
import Emojis from "../emojipedia";

function EmjCrt(emoji) {
  return (
    <Dd
      key={emoji.id}
      emoji={emoji.emoji}
      name={emoji.name}
      disc={emoji.meaning}
    />
  );
}

function App() {
  return (
    <div>
      <h1>
        <span>Emojipedia</span>
      </h1>

      <dl className="dictionary">{Emojis.map(EmjCrt)}</dl>
    </div>
  );
}

export default App;
