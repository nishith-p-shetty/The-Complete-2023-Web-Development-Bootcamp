import emojipedia from "./emojipedia";

var numbers = [3, 56, 2, 48, 5];

//Map -Create a new array by doing something with each item in an array.
const num1 = numbers.map(function (x) {
  return x * 2;
});
console.log(num1);

//Filter - Create a new array by keeping the items that return true.
const num2 = numbers.filter(function (x) {
  return x > 10;
});
console.log(num2);

//Reduce - Accumulate a value by doing something to each item in an array.
const num3 = numbers.reduce(function (accumulator, x) {
  return accumulator + x;
});
console.log(num3);

//Find - find the first item that matches from an array.
const num4 = numbers.find(function (x) {
  return x > 10;
});
console.log(num4);

//FindIndex - find the index of the first item that matches.
const num5 = numbers.findIndex(function (x) {
  return x > 10;
});
console.log(num5);

const new_emojipedia = emojipedia.map(function (x) {
  return x.meaning.substring(0, 100);
});
console.log(new_emojipedia);
