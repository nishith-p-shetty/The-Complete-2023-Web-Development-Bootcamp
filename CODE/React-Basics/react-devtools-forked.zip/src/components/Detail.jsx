import React from "react";
import ReactDOM from "react-dom";

function Detail(props) {
  return <p className="info">{props.detailInfo}</p>;
}

export default Detail;
