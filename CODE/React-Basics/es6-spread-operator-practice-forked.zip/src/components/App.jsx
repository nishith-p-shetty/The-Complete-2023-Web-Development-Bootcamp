import React, { useState } from "react";

function App() {
  const [item, setItem] = useState("");
  const [listItems, setListItems] = useState(["a", "b", "c"]);

  function setitm(event) {
    const item = event.target.value;
    setItem(item);
  }

  function appendItem() {
    //setListItems([...listItems, item]);
    setListItems((prevItems) => {
      return [...prevItems, item];
    });
    setItem("");
  }

  return (
    <div className="container">
      <div className="heading">
        <h1>To-Do List</h1>
      </div>
      <div className="form">
        <input type="text" onChange={setitm} value={item} />
        <button onClick={appendItem}>
          <span>Add</span>
        </button>
      </div>
      <div>
        <ul>
          {listItems.map((itm) => (
            <li>{itm}</li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default App;
