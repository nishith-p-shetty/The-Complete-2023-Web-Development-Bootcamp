import React, { useState } from "react";

function App() {
  const [time, getTime] = useState(new Date().toLocaleTimeString());

  function getTimeOnClick() {
    getTime(new Date().toLocaleTimeString());
  }
  setInterval(getTimeOnClick, 1000);

  return (
    <div className="container">
      <h1>{time}</h1>
      <button onClick={getTimeOnClick}>Get Time</button>
    </div>
  );
}

export default App;
