import React, { useState } from "react";

function App() {
  const [contact, setContact] = useState({
    fName: "",
    lName: "",
    email: ""
  });

  function subdet(event) {
    setContact({
      fName: event.target.form.fName.value,
      lName: event.target.form.lName.value,
      email: event.target.form.email.value
    });
  }

  return (
    <div className="container">
      <h1>
        Hello {contact.fName} {contact.lName}
      </h1>
      <p>{contact.email}</p>
      <form onChange={subdet}>
        <input name="fName" value={contact.fName} placeholder="First Name" />
        <input name="lName" value={contact.lName} placeholder="Last Name" />
        <input name="email" value={contact.email} placeholder="Email" />
        <button>Submit</button>
      </form>
    </div>
  );
}

export default App;
